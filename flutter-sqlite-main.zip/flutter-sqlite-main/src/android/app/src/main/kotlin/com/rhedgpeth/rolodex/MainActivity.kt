package com.rhedgpeth.rolodex

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
