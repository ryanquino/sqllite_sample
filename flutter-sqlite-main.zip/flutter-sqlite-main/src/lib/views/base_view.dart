abstract class BaseView {
  void screenUpdate();
}